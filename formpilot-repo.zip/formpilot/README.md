# FormPilot

An open agent that finishes bureaucratic paperwork (scholarships, claims, refunds). You give it the rules and your documents; it plans, fills the form, checks its own work, and asks a human before anything final.

## Problem
Multi-step paperwork wastes hours and fails on small mistakes (name mismatches, wrong date formats, missing attachments). FormPilot does the repetitive 90% and asks the human only for the decisions that matter.

## How it works
1. **Plan:** reads the rules and extracts required fields, documents, deadline, and format constraints.
2. **Extract:** fills each field using only the supplied documents. Missing values stay empty; nothing is invented.
3. **Verify:** a second pass checks each field against the rules and across documents, corrects what it can, then re-checks.
4. **Human approval:** unresolved items are flagged "Needs you". Nothing is exported without approval.
5. **Export:** draft cover email, reminder suggestion, and a JSON file with final values, source of every value, and a full audit log.

## Files
- `formpilot-agent.html`: the working agent (single file).
- `demo/formpilot-demo.html`: scripted, auto-playing walkthrough for screen recording. It is a simulation, not the agent.

## Running it
`formpilot-agent.html` calls Claude through the Claude artifact runtime (`claude.use("sample")`), so it runs when opened inside Claude as a published artifact. It does not run standalone on GitHub Pages. To run it elsewhere, replace the `sample` calls with your own LLM API calls.

## Limitations
- Documents are text only (no PDF/image parsing yet).
- Does not submit to real websites.
- Do not use real sensitive documents in demos.

## Sample scenario
Click **Load sample** in the agent. It includes a planted name mismatch and date-format error that the verifier catches.

## License
MIT
